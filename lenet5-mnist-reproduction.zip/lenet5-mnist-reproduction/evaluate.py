"""
LeNet-5 模型评估脚本

输出测试集准确率、F1、AUC、混淆矩阵及错误案例分析。

用法:
    python evaluate.py
    python evaluate.py --checkpoint results/checkpoints/best_model.pth
"""

import os
import argparse
import torch
import torch.nn as nn
import numpy as np

import config
from models.lenet5 import build_model
from utils.dataset import load_mnist_data
from utils.metrics import compute_classification_metrics, save_metrics_report
from utils.visualization import (
    plot_confusion_matrix,
    plot_sample_predictions,
    plot_error_cases,
    plot_roc_curves,
    save_classification_report,
)
from utils.environment import save_environment_info


def get_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


@torch.no_grad()
def collect_predictions(model, loader, device):
    """收集预测标签与概率分数"""
    model.eval()
    all_preds, all_labels, all_scores = [], [], []

    for images, labels in loader:
        images = images.to(device)
        outputs = model(images)
        probs = torch.softmax(outputs, dim=1)
        _, preds = outputs.max(1)
        all_preds.extend(preds.cpu().numpy())
        all_labels.extend(labels.numpy())
        all_scores.extend(probs.cpu().numpy())

    return np.array(all_labels), np.array(all_preds), np.array(all_scores)


def main():
    parser = argparse.ArgumentParser(description="LeNet-5 MNIST 完整评估")
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=os.path.join(config.CHECKPOINT_DIR, "best_model.pth"),
    )
    args = parser.parse_args()

    device = get_device()
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    os.makedirs(config.RESULTS_DIR, exist_ok=True)

    print("=" * 60)
    print("LeNet-5 模型完整评估与分析")
    print("=" * 60)
    save_environment_info()

    _, _, test_loader = load_mnist_data(batch_size=config.BATCH_SIZE)
    model = build_model(num_classes=config.NUM_CLASSES).to(device)

    if not os.path.exists(args.checkpoint):
        print(f"错误: 未找到模型文件 {args.checkpoint}")
        print("请先运行 python train.py 或 python compare_experiment.py")
        return

    checkpoint = torch.load(args.checkpoint, map_location=device, weights_only=False)
    if isinstance(checkpoint, dict) and "model_state_dict" in checkpoint:
        model.load_state_dict(checkpoint["model_state_dict"])
        if "val_acc" in checkpoint:
            print(f"加载模型 (验证准确率: {checkpoint['val_acc']:.2f}%)")
    else:
        model.load_state_dict(checkpoint)
        print("加载模型权重")

    # 收集预测
    y_true, y_pred, y_score = collect_predictions(model, test_loader, device)

    metrics = compute_classification_metrics(y_true, y_pred, y_score)
    save_metrics_report(metrics, os.path.join(config.RESULTS_DIR, "lenet_metrics.txt"), "LeNet-5")
    save_metrics_report(metrics, os.path.join(config.RESULTS_DIR, "metrics_report.txt"), "LeNet-5")

    print(f"\n【定量评估结果】")
    print(f"  准确率 (Accuracy):  {metrics['accuracy']*100:.2f}%")
    print(f"  精确率 (Precision): macro={metrics['precision_macro']:.4f}, weighted={metrics['precision_weighted']:.4f}")
    print(f"  召回率 (Recall):    macro={metrics['recall_macro']:.4f}, weighted={metrics['recall_weighted']:.4f}")
    print(f"  F1 值:              macro={metrics['f1_macro']:.4f}, weighted={metrics['f1_weighted']:.4f}")
    if metrics.get("auc_macro"):
        print(f"  AUC:                macro={metrics['auc_macro']:.4f}, weighted={metrics['auc_weighted']:.4f}")
    print(f"  错误率:             {metrics['error_rate']*100:.2f}% ({metrics['error_count']}/{metrics['total_samples']})")

    # 生成可视化
    print(f"\n【生成可视化图表】")
    plot_confusion_matrix(
        y_true, y_pred,
        save_path=os.path.join(config.FIGURES_DIR, "confusion_matrix.png"),
    )
    plot_roc_curves(
        y_true, y_score,
        save_path=os.path.join(config.FIGURES_DIR, "roc_curves.png"),
    )
    plot_sample_predictions(
        model, test_loader, device,
        save_path=os.path.join(config.FIGURES_DIR, "sample_predictions.png"),
    )
    plot_error_cases(
        model, test_loader, device,
        save_path=os.path.join(config.FIGURES_DIR, "error_cases.png"),
    )
    save_classification_report(
        y_true, y_pred,
        save_path=os.path.join(config.RESULTS_DIR, "classification_report.txt"),
    )

    # 错误分析
    print(f"\n【错误案例分析】")
    errors = y_true != y_pred
    if errors.sum() > 0:
        from collections import Counter
        pairs = Counter((y_true[i], y_pred[i]) for i in range(len(y_true)) if errors[i])
        print("  常见混淆对 (真实→预测):")
        for (t, p), count in pairs.most_common(5):
            print(f"    {t} → {p}: {count} 次")
        print("\n  可能原因:")
        print("    - 数字形态相似 (如 4/9、3/8、5/6)")
        print("    - 书写不规范 (倾斜、笔画断裂)")
        print("    - 模型对局部特征敏感，缺乏全局上下文")

    print(f"\n所有结果已保存至: {config.RESULTS_DIR}")
    print("=" * 60)


if __name__ == "__main__":
    main()
