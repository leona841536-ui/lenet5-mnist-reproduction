"""数据集加载与预处理工具"""

import os
import torch
from torch.utils.data import DataLoader, random_split
from torchvision import datasets, transforms

import config


def get_mnist_transforms(input_size: int = 32):
    """
    MNIST 数据预处理流水线

    LeNet-5 原始输入尺寸为 32×32，MNIST 原始为 28×28，
    通过 Padding 填充至 32×32 以匹配原始架构。
    """
    return transforms.Compose([
        transforms.Pad((2, 2)),                          # 28×28 → 32×32
        transforms.ToTensor(),                         # 转为 [0,1] 张量
        transforms.Normalize((0.1307,), (0.3081,)),    # MNIST 标准归一化
    ])


def load_mnist_data(
    batch_size: int = 64,
    val_ratio: float = 0.1,
    num_workers: int = 0,
):
    """
    加载 MNIST 数据集并划分训练集/验证集/测试集

    Returns:
        train_loader, val_loader, test_loader
    """
    os.makedirs(config.DATA_DIR, exist_ok=True)
    transform = get_mnist_transforms(config.INPUT_SIZE)

    # 下载并加载完整训练集
    full_train = datasets.MNIST(
        root=config.DATA_DIR,
        train=True,
        download=True,
        transform=transform,
    )

    # 划分训练集与验证集 (90% / 10%)
    val_size = int(len(full_train) * val_ratio)
    train_size = len(full_train) - val_size
    train_set, val_set = random_split(
        full_train,
        [train_size, val_size],
        generator=torch.Generator().manual_seed(config.SEED),
    )

    test_set = datasets.MNIST(
        root=config.DATA_DIR,
        train=False,
        download=True,
        transform=transform,
    )

    train_loader = DataLoader(
        train_set, batch_size=batch_size, shuffle=True, num_workers=num_workers
    )
    val_loader = DataLoader(
        val_set, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )
    test_loader = DataLoader(
        test_set, batch_size=batch_size, shuffle=False, num_workers=num_workers
    )

    return train_loader, val_loader, test_loader


def get_dataset_info():
    """返回数据集基本信息（用于文档与日志）"""
    return {
        "name": "MNIST",
        "description": "手写数字识别数据集",
        "num_classes": 10,
        "train_samples": 60000,
        "test_samples": 10000,
        "image_size": "28×28 (填充至 32×32)",
        "channels": 1,
    }
