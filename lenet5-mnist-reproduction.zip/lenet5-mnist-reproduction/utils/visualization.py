"""训练过程可视化与结果分析工具"""

import os
import json
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report

import config

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def plot_training_curves(history: dict, save_path: str = None, title: str = "LeNet-5"):
    """绘制训练/验证损失与准确率曲线"""
    epochs = range(1, len(history["train_loss"]) + 1)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4))

    axes[0].plot(epochs, history["train_loss"], "b-o", label="训练损失", markersize=4)
    axes[0].plot(epochs, history["val_loss"], "r-o", label="验证损失", markersize=4)
    axes[0].set_xlabel("Epoch")
    axes[0].set_ylabel("Loss")
    axes[0].set_title(f"{title} 训练与验证损失")
    axes[0].legend()
    axes[0].grid(True, alpha=0.3)

    axes[1].plot(epochs, history["train_acc"], "b-o", label="训练准确率", markersize=4)
    axes[1].plot(epochs, history["val_acc"], "r-o", label="验证准确率", markersize=4)
    axes[1].set_xlabel("Epoch")
    axes[1].set_ylabel("Accuracy (%)")
    axes[1].set_title(f"{title} 训练与验证准确率")
    axes[1].legend()
    axes[1].grid(True, alpha=0.3)

    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"训练曲线已保存: {save_path}")
    plt.close()


def plot_confusion_matrix(y_true, y_pred, save_path: str = None, title: str = "LeNet-5 混淆矩阵"):
    """绘制混淆矩阵"""
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=range(10), yticklabels=range(10))
    plt.xlabel("预测标签")
    plt.ylabel("真实标签")
    plt.title(title)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"混淆矩阵已保存: {save_path}")
    plt.close()
    return cm


def plot_roc_curves(y_true, y_score, save_path: str = None, num_classes: int = 10):
    """绘制多分类 ROC 曲线"""
    from sklearn.preprocessing import label_binarize
    from sklearn.metrics import roc_curve, auc

    y_bin = label_binarize(y_true, classes=list(range(num_classes)))
    plt.figure(figsize=(8, 6))

    for i in range(num_classes):
        fpr, tpr, _ = roc_curve(y_bin[:, i], y_score[:, i])
        roc_auc = auc(fpr, tpr)
        plt.plot(fpr, tpr, lw=1.5, label=f"数字 {i} (AUC={roc_auc:.3f})")

    plt.plot([0, 1], [0, 1], "k--", lw=1, label="随机猜测")
    plt.xlabel("假阳性率 (FPR)")
    plt.ylabel("真阳性率 (TPR)")
    plt.title("LeNet-5 多分类 ROC 曲线 (One-vs-Rest)")
    plt.legend(loc="lower right", fontsize=8)
    plt.grid(alpha=0.3)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"ROC 曲线已保存: {save_path}")
    plt.close()


def plot_sample_predictions(model, test_loader, device, save_path: str = None, num_samples: int = 16):
    """可视化模型预测样例"""
    import torch

    model.eval()
    images, labels = next(iter(test_loader))
    images, labels = images[:num_samples].to(device), labels[:num_samples]

    with torch.no_grad():
        outputs = model(images)
        probs = torch.softmax(outputs, dim=1)
        _, preds = outputs.max(1)

    fig, axes = plt.subplots(4, 4, figsize=(9, 9))
    for i, ax in enumerate(axes.flat):
        img = images[i].cpu().squeeze().numpy()
        img = img * 0.3081 + 0.1307
        ax.imshow(img, cmap="gray")
        color = "green" if preds[i] == labels[i] else "red"
        conf = probs[i][preds[i]].item() * 100
        ax.set_title(f"真:{labels[i].item()} 预:{preds[i].item()} ({conf:.0f}%)", color=color, fontsize=9)
        ax.axis("off")

    plt.suptitle("预测样例 (绿=正确, 红=错误)", fontsize=12)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"预测样例已保存: {save_path}")
    plt.close()


def plot_error_cases(model, test_loader, device, save_path: str = None, max_errors: int = 12):
    """可视化典型误分类样本"""
    import torch

    model.eval()
    error_images, error_true, error_pred, error_probs = [], [], [], []

    for images, labels in test_loader:
        images_dev = images.to(device)
        with torch.no_grad():
            outputs = model(images_dev)
            probs = torch.softmax(outputs, dim=1)
            _, preds = outputs.max(1)

        for i in range(len(labels)):
            if preds[i] != labels[i]:
                error_images.append(images[i])
                error_true.append(labels[i].item())
                error_pred.append(preds[i].item())
                error_probs.append(probs[i][preds[i]].item())
                if len(error_images) >= max_errors:
                    break
        if len(error_images) >= max_errors:
            break

    if not error_images:
        print("未找到错误样本")
        return

    n = len(error_images)
    cols = min(4, n)
    rows = (n + cols - 1) // cols
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2.5, rows * 2.5))
    if rows == 1 and cols == 1:
        axes = np.array([[axes]])
    elif rows == 1:
        axes = axes.reshape(1, -1)
    elif cols == 1:
        axes = axes.reshape(-1, 1)

    for i in range(rows * cols):
        r, c = divmod(i, cols)
        ax = axes[r, c]
        if i < n:
            img = error_images[i].squeeze().numpy() * 0.3081 + 0.1307
            ax.imshow(img, cmap="gray")
            ax.set_title(
                f"真实:{error_true[i]} → 预测:{error_pred[i]}\n置信度:{error_probs[i]*100:.1f}%",
                fontsize=9, color="red",
            )
        ax.axis("off")

    plt.suptitle("典型错误案例分析", fontsize=12)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"错误案例图已保存: {save_path}")
    plt.close()


def plot_model_comparison(comparison_data: dict, save_path: str = None):
    """绘制 MLP vs LeNet-5 对照实验柱状图"""
    models = list(comparison_data.keys())
    metrics_names = ["准确率(%)", "精确率", "召回率", "F1值"]
    keys = ["accuracy", "precision_macro", "recall_macro", "f1_macro"]

    fig, axes = plt.subplots(1, 4, figsize=(14, 4))
    colors = ["#4C72B0", "#DD8452"]

    for ax, metric_name, key in zip(axes, metrics_names, keys):
        values = []
        for m in models:
            val = comparison_data[m].get(key, 0)
            if key == "accuracy":
                val *= 100
            values.append(val)
        bars = ax.bar(models, values, color=colors[:len(models)], edgecolor="white")
        ax.set_title(metric_name)
        ax.set_ylim(0, 105 if key == "accuracy" else 1.05)
        for bar, val in zip(bars, values):
            fmt = f"{val:.2f}" if key == "accuracy" else f"{val:.3f}"
            ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.01,
                    fmt, ha="center", va="bottom", fontsize=9)
        ax.grid(axis="y", alpha=0.3)

    plt.suptitle("对照实验: MLP 基线 vs LeNet-5", fontsize=12)
    plt.tight_layout()
    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=150, bbox_inches="tight")
        print(f"对照实验图已保存: {save_path}")
    plt.close()


def save_classification_report(y_true, y_pred, save_path: str, model_name: str = "LeNet-5"):
    """保存 sklearn 分类报告"""
    report = classification_report(y_true, y_pred, digits=4)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, "w", encoding="utf-8") as f:
        f.write(f"{model_name} MNIST 分类报告\n")
        f.write("=" * 50 + "\n\n")
        f.write(report)
    print(f"分类报告已保存: {save_path}")
    return report


def save_history_json(history: dict, save_path: str):
    """保存训练历史为 JSON"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    with open(save_path, "w", encoding="utf-8") as f:
        json.dump(history, f, indent=2, ensure_ascii=False)
    print(f"训练历史已保存: {save_path}")
