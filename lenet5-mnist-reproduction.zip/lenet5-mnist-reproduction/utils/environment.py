"""实验环境信息"""

import json
import os
import platform
import sys
from datetime import datetime

import config


def collect_environment_info() -> dict:
    """收集硬件与软件环境信息"""
    info = {
        "采集时间": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "操作系统": platform.platform(),
        "处理器": platform.processor() or platform.machine(),
        "Python版本": sys.version.split()[0],
        "PyTorch版本": None,
        "CUDA可用": False,
        "GPU型号": None,
    }

    try:
        import torch
        info["PyTorch版本"] = torch.__version__
        info["CUDA可用"] = torch.cuda.is_available()
        if torch.cuda.is_available():
            info["GPU型号"] = torch.cuda.get_device_name(0)
            info["CUDA版本"] = torch.version.cuda
    except ImportError:
        info["PyTorch版本"] = "未安装"

    return info


def save_environment_info(save_path: str = None):
    """保存环境信息到 JSON 和文本"""
    if save_path is None:
        save_path = os.path.join(config.RESULTS_DIR, "environment_info.txt")

    info = collect_environment_info()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    json_path = save_path.replace(".txt", ".json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(info, f, indent=2, ensure_ascii=False)

    with open(save_path, "w", encoding="utf-8") as f:
        f.write("实验环境信息\n")
        f.write("=" * 40 + "\n")
        for k, v in info.items():
            f.write(f"{k}: {v}\n")

    print(f"环境信息已保存: {save_path}")
    return info
