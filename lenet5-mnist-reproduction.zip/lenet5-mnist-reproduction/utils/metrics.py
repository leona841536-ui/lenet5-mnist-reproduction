"""分类任务评估指标计算"""

import json
import os
from typing import Dict, Tuple

import numpy as np
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)


def compute_classification_metrics(
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_score: np.ndarray = None,
    num_classes: int = 10,
) -> Dict:
    """
    计算完整分类评估指标

    Returns:
        包含 accuracy, precision, recall, f1, sensitivity, specificity,
        per-class metrics, macro/weighted averages 的字典
    """
    cm = confusion_matrix(y_true, y_pred, labels=list(range(num_classes)))

    # 各类别 sensitivity (recall) 与 specificity
    per_class = {}
    for i in range(num_classes):
        tp = cm[i, i]
        fn = cm[i, :].sum() - tp
        fp = cm[:, i].sum() - tp
        tn = cm.sum() - tp - fn - fp
        sensitivity = tp / (tp + fn) if (tp + fn) > 0 else 0.0
        specificity = tn / (tn + fp) if (tn + fp) > 0 else 0.0
        per_class[str(i)] = {
            "precision": float(precision_score(y_true == i, y_pred == i, zero_division=0)),
            "recall": float(recall_score(y_true == i, y_pred == i, zero_division=0)),
            "f1": float(f1_score(y_true == i, y_pred == i, zero_division=0)),
            "sensitivity": float(sensitivity),
            "specificity": float(specificity),
            "support": int((y_true == i).sum()),
        }

    metrics = {
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "precision_macro": float(precision_score(y_true, y_pred, average="macro", zero_division=0)),
        "recall_macro": float(recall_score(y_true, y_pred, average="macro", zero_division=0)),
        "f1_macro": float(f1_score(y_true, y_pred, average="macro", zero_division=0)),
        "precision_weighted": float(precision_score(y_true, y_pred, average="weighted", zero_division=0)),
        "recall_weighted": float(recall_score(y_true, y_pred, average="weighted", zero_division=0)),
        "f1_weighted": float(f1_score(y_true, y_pred, average="weighted", zero_division=0)),
        "per_class": per_class,
        "confusion_matrix": cm.tolist(),
        "total_samples": int(len(y_true)),
        "error_count": int((y_true != y_pred).sum()),
        "error_rate": float((y_true != y_pred).mean()),
    }

    # ROC-AUC (one-vs-rest, macro average)
    if y_score is not None:
        try:
            metrics["auc_macro"] = float(
                roc_auc_score(y_true, y_score, multi_class="ovr", average="macro")
            )
            metrics["auc_weighted"] = float(
                roc_auc_score(y_true, y_score, multi_class="ovr", average="weighted")
            )
        except ValueError:
            metrics["auc_macro"] = None
            metrics["auc_weighted"] = None

    return metrics


def get_roc_data(y_true: np.ndarray, y_score: np.ndarray, num_classes: int = 10):
    """计算各类别 ROC 曲线数据"""
    from sklearn.preprocessing import label_binarize

    y_bin = label_binarize(y_true, classes=list(range(num_classes)))
    roc_data = {"fpr": {}, "tpr": {}, "auc": {}}

    for i in range(num_classes):
        fpr, tpr, _ = roc_curve(y_bin[:, i], y_score[:, i])
        auc_val = roc_auc_score(y_bin[:, i], y_score[:, i])
        roc_data["fpr"][str(i)] = fpr.tolist()
        roc_data["tpr"][str(i)] = tpr.tolist()
        roc_data["auc"][str(i)] = float(auc_val)

    return roc_data


def save_metrics_report(metrics: dict, save_path: str, model_name: str = "Model"):
    """保存指标报告为文本与 JSON"""
    os.makedirs(os.path.dirname(save_path), exist_ok=True)

    json_path = save_path.replace(".txt", ".json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, indent=2, ensure_ascii=False)

    with open(save_path, "w", encoding="utf-8") as f:
        f.write(f"{model_name} 分类评估指标报告\n")
        f.write("=" * 55 + "\n\n")
        f.write(f"准确率 (Accuracy):     {metrics['accuracy']:.4f} ({metrics['accuracy']*100:.2f}%)\n")
        f.write(f"精确率 (Precision):    macro={metrics['precision_macro']:.4f}, weighted={metrics['precision_weighted']:.4f}\n")
        f.write(f"召回率 (Recall):       macro={metrics['recall_macro']:.4f}, weighted={metrics['recall_weighted']:.4f}\n")
        f.write(f"F1 值:                 macro={metrics['f1_macro']:.4f}, weighted={metrics['f1_weighted']:.4f}\n")
        if metrics.get("auc_macro") is not None:
            f.write(f"AUC:                   macro={metrics['auc_macro']:.4f}, weighted={metrics['auc_weighted']:.4f}\n")
        f.write(f"错误率:                {metrics['error_rate']:.4f} ({metrics['error_count']}/{metrics['total_samples']})\n\n")

        f.write("各类别详细指标:\n")
        f.write("-" * 55 + "\n")
        f.write(f"{'类别':<6}{'Precision':<12}{'Recall':<12}{'F1':<12}{'Sensitivity':<14}{'Specificity':<12}{'Support':<8}\n")
        for cls, m in metrics["per_class"].items():
            f.write(
                f"{cls:<6}{m['precision']:<12.4f}{m['recall']:<12.4f}{m['f1']:<12.4f}"
                f"{m['sensitivity']:<14.4f}{m['specificity']:<12.4f}{m['support']:<8}\n"
            )

    return save_path, json_path


def format_metrics_table_row(model_name: str, metrics: dict) -> dict:
    """格式化为对照实验表格行"""
    return {
        "模型": model_name,
        "准确率(%)": round(metrics["accuracy"] * 100, 2),
        "精确率": round(metrics["precision_macro"], 4),
        "召回率": round(metrics["recall_macro"], 4),
        "F1值": round(metrics["f1_macro"], 4),
        "AUC": round(metrics.get("auc_macro") or 0, 4) if metrics.get("auc_macro") else "—",
        "错误率(%)": round(metrics["error_rate"] * 100, 2),
    }
