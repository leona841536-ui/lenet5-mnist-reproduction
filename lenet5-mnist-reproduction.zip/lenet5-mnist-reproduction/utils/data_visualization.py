"""MNIST 数据可视化"""

import os
import numpy as np
import matplotlib.pyplot as plt
from torchvision import datasets

import config

plt.rcParams["font.sans-serif"] = ["SimHei", "Microsoft YaHei", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False


def _load_raw_mnist():
    """加载未预处理的 MNIST 原始数据"""
    os.makedirs(config.DATA_DIR, exist_ok=True)
    train_set = datasets.MNIST(root=config.DATA_DIR, train=True, download=True, transform=None)
    test_set = datasets.MNIST(root=config.DATA_DIR, train=False, download=True, transform=None)
    return train_set, test_set


def plot_class_distribution(save_path: str):
    """绘制训练集类别分布直方图"""
    train_set, _ = _load_raw_mnist()
    labels = np.array(train_set.targets)
    counts = np.bincount(labels, minlength=10)

    fig, ax = plt.subplots(figsize=(8, 5))
    bars = ax.bar(range(10), counts, color="steelblue", edgecolor="white")
    ax.set_xlabel("数字类别")
    ax.set_ylabel("样本数量")
    ax.set_title("MNIST 训练集类别分布")
    ax.set_xticks(range(10))
    for bar, count in zip(bars, counts):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 100,
                str(count), ha="center", va="bottom", fontsize=9)
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"类别分布图已保存: {save_path}")
    return counts.tolist()


def plot_pixel_histogram(save_path: str, num_samples: int = 5000):
    """绘制像素值分布直方图"""
    train_set, _ = _load_raw_mnist()
    indices = np.random.choice(len(train_set), min(num_samples, len(train_set)), replace=False)
    pixels = []
    for idx in indices:
        img, _ = train_set[idx]
        pixels.extend(np.array(img).flatten())
    pixels = np.array(pixels)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(pixels, bins=50, color="coral", edgecolor="white", alpha=0.8)
    ax.set_xlabel("像素值 (0-255)")
    ax.set_ylabel("频数")
    ax.set_title(f"MNIST 像素值分布 (随机 {len(indices)} 张样本)")
    ax.axvline(pixels.mean(), color="red", linestyle="--", label=f"均值={pixels.mean():.1f}")
    ax.legend()
    ax.grid(axis="y", alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"像素直方图已保存: {save_path}")


def plot_sample_images(save_path: str, num_per_class: int = 5):
    """展示每个类别的样本图像"""
    train_set, _ = _load_raw_mnist()
    fig, axes = plt.subplots(10, num_per_class, figsize=(num_per_class * 1.5, 15))
    class_counts = {i: 0 for i in range(10)}

    for img, label in train_set:
        if class_counts[label] < num_per_class:
            row, col = label, class_counts[label]
            axes[row, col].imshow(np.array(img), cmap="gray")
            axes[row, col].axis("off")
            if col == 0:
                axes[row, col].set_ylabel(f"数字 {label}", fontsize=10)
            class_counts[label] += 1
        if all(v >= num_per_class for v in class_counts.values()):
            break

    plt.suptitle("MNIST 数据集样本展示 (每类 5 张)", fontsize=12)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"样本展示图已保存: {save_path}")


def plot_preprocessing_comparison(save_path: str, num_samples: int = 6):
    """展示预处理前后对比"""
    from utils.dataset import get_mnist_transforms

    train_set_raw, _ = _load_raw_mnist()
    transform = get_mnist_transforms()

    fig, axes = plt.subplots(2, num_samples, figsize=(num_samples * 2, 4))

    for i in range(num_samples):
        img_raw, label = train_set_raw[i]
        img_arr = np.array(img_raw)

        # 原始 28×28
        axes[0, i].imshow(img_arr, cmap="gray")
        axes[0, i].set_title(f"原始 28×28\n标签:{label}", fontsize=9)
        axes[0, i].axis("off")

        # 预处理后 32×32
        img_processed = transform(img_raw).squeeze().numpy()
        img_display = img_processed * 0.3081 + 0.1307  # 反归一化便于显示
        axes[1, i].imshow(img_display, cmap="gray")
        axes[1, i].set_title("填充+归一化 32×32", fontsize=9)
        axes[1, i].axis("off")

    axes[0, 0].set_ylabel("预处理前", fontsize=10)
    axes[1, 0].set_ylabel("预处理后", fontsize=10)
    plt.suptitle("数据预处理前后对比", fontsize=12)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"预处理对比图已保存: {save_path}")


def plot_image_size_scatter(save_path: str, num_samples: int = 2000):
    """绘制非零像素数散点图（反映数字笔画复杂度）"""
    train_set, _ = _load_raw_mnist()
    indices = np.random.choice(len(train_set), min(num_samples, len(train_set)), replace=False)

    labels_list, nonzero_counts = [], []
    for idx in indices:
        img, label = train_set[idx]
        arr = np.array(img)
        labels_list.append(label)
        nonzero_counts.append((arr > 0).sum())

    fig, ax = plt.subplots(figsize=(8, 5))
    colors = plt.cm.tab10(np.array(labels_list) / 10)
    ax.scatter(labels_list, nonzero_counts, c=colors, alpha=0.4, s=10)
    ax.set_xlabel("数字类别")
    ax.set_ylabel("非零像素数量")
    ax.set_title("各类别手写数字笔画复杂度分布 (散点图)")
    ax.set_xticks(range(10))
    ax.grid(alpha=0.3)
    plt.tight_layout()
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=150, bbox_inches="tight")
    plt.close()
    print(f"散点图已保存: {save_path}")


def generate_all_data_figures(output_dir: str = None):
    """生成全部数据可视化图表"""
    if output_dir is None:
        output_dir = os.path.join(config.FIGURES_DIR, "data")

    os.makedirs(output_dir, exist_ok=True)
    np.random.seed(config.SEED)

    counts = plot_class_distribution(os.path.join(output_dir, "class_distribution.png"))
    plot_pixel_histogram(os.path.join(output_dir, "pixel_histogram.png"))
    plot_sample_images(os.path.join(output_dir, "sample_images.png"))
    plot_preprocessing_comparison(os.path.join(output_dir, "preprocessing_comparison.png"))
    plot_image_size_scatter(os.path.join(output_dir, "stroke_complexity_scatter.png"))

    return {
        "class_counts": counts,
        "output_dir": output_dir,
    }
