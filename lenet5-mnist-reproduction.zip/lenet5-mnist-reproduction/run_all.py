"""
一键运行完整实验流程

依次执行:
  1. 数据可视化
  2. 对照实验 (MLP vs LeNet-5)
  3. 模型评估

用法:
  python run_all.py
  python run_all.py --epochs 10
  python run_all.py --skip-compare   # 已有权重时跳过训练
"""

import argparse
import subprocess
import sys
import os

import config


def run_step(script: str, args: list = None):
    cmd = [sys.executable, script] + (args or [])
    print(f"\n{'='*60}")
    print(f"执行: {' '.join(cmd)}")
    print(f"{'='*60}\n")
    result = subprocess.run(cmd, cwd=config.ROOT_DIR)
    if result.returncode != 0:
        print(f"错误: {script} 执行失败 (exit code {result.returncode})")
        sys.exit(result.returncode)


def main():
    parser = argparse.ArgumentParser(description="LeNet-5 MNIST 实验一键运行")
    parser.add_argument("--epochs", type=int, default=config.EPOCHS)
    parser.add_argument("--skip-data-viz", action="store_true", help="跳过数据可视化")
    parser.add_argument("--skip-compare", action="store_true", help="跳过对照实验（不重新训练）")
    args = parser.parse_args()

    print("=" * 60)
    print("LeNet-5 MNIST 手写数字识别实验")
    print("=" * 60)

    os.makedirs(config.RESULTS_DIR, exist_ok=True)

    if not args.skip_data_viz:
        run_step("visualize_data.py")

    if not args.skip_compare:
        run_step("compare_experiment.py", ["--epochs", str(args.epochs)])
    elif not os.path.exists(os.path.join(config.CHECKPOINT_DIR, "best_model.pth")):
        run_step("train.py", ["--epochs", str(args.epochs)])

    run_step("evaluate.py")

    print("\n" + "=" * 60)
    print("实验完成")
    print("=" * 60)
    print(f"  图表: {config.FIGURES_DIR}/")
    print(f"  指标: {config.RESULTS_DIR}/")
    print(f"  权重: {config.CHECKPOINT_DIR}/")
    print("=" * 60)


if __name__ == "__main__":
    main()
