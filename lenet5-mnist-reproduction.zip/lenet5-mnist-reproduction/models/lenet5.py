"""
LeNet-5 卷积神经网络模型

参考论文: LeCun Y, Bottou L, Bengio Y, Haffner P.
         Gradient-based learning applied to document recognition.
         Proceedings of the IEEE, 1998, 86(11): 2278-2324.

原始架构:
  INPUT(32×32) → C1(6@5×5) → S2(2×2 avg pool) → C3(16@5×5) → S4(2×2 avg pool)
              → C5(120) → F6(84) → OUTPUT(10)

说明:
  - 原始 LeNet-5 使用 tanh 激活与平均池化；本实现采用 ReLU + 平均池化，
    这是学术界最常见的复现方式，收敛更快且效果相当。
  - C3 层在原始论文中使用部分连接（not fully connected to S2）；
    本实现采用全连接卷积以简化实现，与多数开源复现一致。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class LeNet5(nn.Module):
    """LeNet-5 手写数字识别网络"""

    def __init__(self, num_classes: int = 10):
        super().__init__()
        self.num_classes = num_classes

        # C1: 输入 1×32×32 → 输出 6×28×28
        self.conv1 = nn.Conv2d(1, 6, kernel_size=5, padding=0)

        # S2: 6×28×28 → 6×14×14 (平均池化)
        self.pool1 = nn.AvgPool2d(kernel_size=2, stride=2)

        # C3: 6×14×14 → 16×10×10
        self.conv2 = nn.Conv2d(6, 16, kernel_size=5, padding=0)

        # S4: 16×10×10 → 16×5×5
        self.pool2 = nn.AvgPool2d(kernel_size=2, stride=2)

        # C5: 16×5×5 → 120 (全连接卷积层)
        self.conv3 = nn.Conv2d(16, 120, kernel_size=5, padding=0)

        # F6: 120 → 84
        self.fc1 = nn.Linear(120, 84)

        # OUTPUT: 84 → num_classes
        self.fc2 = nn.Linear(84, num_classes)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        # C1 + 激活
        x = F.relu(self.conv1(x))       # [B, 6, 28, 28]
        x = self.pool1(x)               # [B, 6, 14, 14]

        # C3 + 激活
        x = F.relu(self.conv2(x))       # [B, 16, 10, 10]
        x = self.pool2(x)               # [B, 16, 5, 5]

        # C5 + 激活
        x = F.relu(self.conv3(x))       # [B, 120, 1, 1]
        x = x.view(x.size(0), -1)       # [B, 120]

        # F6 + 激活
        x = F.relu(self.fc1(x))         # [B, 84]

        # 输出层（CrossEntropyLoss 内含 Softmax，此处不加）
        x = self.fc2(x)                 # [B, num_classes]
        return x

    def count_parameters(self) -> int:
        """统计可训练参数量"""
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def build_model(num_classes: int = 10) -> LeNet5:
    """构建 LeNet-5 模型"""
    model = LeNet5(num_classes=num_classes)
    return model
