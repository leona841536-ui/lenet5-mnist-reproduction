"""
多层感知机 (MLP) 基线模型

用于与 LeNet-5 进行对照实验，验证卷积神经网络相对于
全连接网络在手写数字识别任务中的优势。
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class MLPBaseline(nn.Module):
    """三层全连接网络基线模型"""

    def __init__(self, input_size: int = 32, num_classes: int = 10):
        super().__init__()
        flat_size = input_size * input_size  # 32×32 = 1024

        self.fc1 = nn.Linear(flat_size, 512)
        self.fc2 = nn.Linear(512, 256)
        self.fc3 = nn.Linear(256, num_classes)
        self.dropout = nn.Dropout(0.2)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = x.view(x.size(0), -1)
        x = F.relu(self.fc1(x))
        x = self.dropout(x)
        x = F.relu(self.fc2(x))
        x = self.dropout(x)
        x = self.fc3(x)
        return x

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def build_mlp(num_classes: int = 10, input_size: int = 32) -> MLPBaseline:
    return MLPBaseline(input_size=input_size, num_classes=num_classes)
