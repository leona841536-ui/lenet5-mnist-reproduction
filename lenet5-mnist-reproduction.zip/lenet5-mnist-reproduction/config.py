"""LeNet-5 复现实验配置文件"""

import os

# 项目根目录
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))

# 数据与结果路径
DATA_DIR = os.path.join(ROOT_DIR, "data")
RESULTS_DIR = os.path.join(ROOT_DIR, "results")
CHECKPOINT_DIR = os.path.join(RESULTS_DIR, "checkpoints")
FIGURES_DIR = os.path.join(RESULTS_DIR, "figures")

# 数据集配置
DATASET_NAME = "MNIST"
NUM_CLASSES = 10
INPUT_SIZE = 32  # LeNet-5 原始输入为 32×32，MNIST 28×28 需填充

# 训练超参数（参考 LeCun 等人原始论文及常见复现设置）
BATCH_SIZE = 64
EPOCHS = 10
LEARNING_RATE = 0.001
WEIGHT_DECAY = 0.0001
MOMENTUM = 0.9  # 原始论文使用 SGD + momentum

# 随机种子（保证可复现）
SEED = 42

# 设备（自动检测 GPU）
DEVICE = "cuda"  # 运行时由 train.py 自动 fallback 到 cpu

# 模型名称
MODEL_NAME = "LeNet-5"
