import os
import json
import config
from utils.data_visualization import generate_all_data_figures
from utils.environment import save_environment_info


def main():
    print("=" * 60)
    print("MNIST 数据集可视化")
    print("=" * 60)

    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    save_environment_info()

    result = generate_all_data_figures()
    stats_path = os.path.join(config.RESULTS_DIR, "data_stats.json")
    with open(stats_path, "w", encoding="utf-8") as f:
        json.dump({"class_counts": result["class_counts"]}, f, ensure_ascii=False, indent=2)
    print(f"\n全部图表已保存至: {result['output_dir']}")
    print("类别样本数:", result["class_counts"])


if __name__ == "__main__":
    main()
