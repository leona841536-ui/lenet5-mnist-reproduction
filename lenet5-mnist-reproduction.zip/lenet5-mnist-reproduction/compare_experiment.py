"""
对照实验: MLP 基线 vs LeNet-5

在相同数据集与超参数下对比全连接网络与卷积网络性能。

用法: python compare_experiment.py
"""

import os
import json
import time
import argparse
import random

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm

import config
from models.lenet5 import build_model
from models.mlp import build_mlp
from utils.dataset import load_mnist_data
from utils.metrics import compute_classification_metrics, save_metrics_report, format_metrics_table_row
from utils.visualization import plot_model_comparison, plot_training_curves, save_history_json
from utils.environment import save_environment_info


def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def get_device():
    return torch.device("cuda" if torch.cuda.is_available() else "cpu")


def train_model(model, train_loader, val_loader, device, epochs, lr, model_name):
    """通用训练函数"""
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=config.WEIGHT_DECAY)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)

    history = {"train_loss": [], "train_acc": [], "val_loss": [], "val_acc": []}
    best_val_acc = 0.0
    best_state = None

    for epoch in range(1, epochs + 1):
        model.train()
        running_loss, correct, total = 0.0, 0, 0
        for images, labels in tqdm(train_loader, desc=f"{model_name} Epoch {epoch}", leave=False):
            images, labels = images.to(device), labels.to(device)
            optimizer.zero_grad()
            outputs = model(images)
            loss = criterion(outputs, labels)
            loss.backward()
            optimizer.step()
            running_loss += loss.item() * images.size(0)
            correct += outputs.argmax(1).eq(labels).sum().item()
            total += labels.size(0)

        train_loss = running_loss / total
        train_acc = 100.0 * correct / total

        model.eval()
        val_loss, val_correct, val_total = 0.0, 0, 0
        with torch.no_grad():
            for images, labels in val_loader:
                images, labels = images.to(device), labels.to(device)
                outputs = model(images)
                loss = criterion(outputs, labels)
                val_loss += loss.item() * images.size(0)
                val_correct += outputs.argmax(1).eq(labels).sum().item()
                val_total += labels.size(0)

        val_loss /= val_total
        val_acc = 100.0 * val_correct / val_total
        scheduler.step()

        history["train_loss"].append(round(train_loss, 4))
        history["train_acc"].append(round(train_acc, 2))
        history["val_loss"].append(round(val_loss, 4))
        history["val_acc"].append(round(val_acc, 2))

        print(f"  [{model_name}] Epoch {epoch}/{epochs} | "
              f"Train Acc: {train_acc:.2f}% | Val Acc: {val_acc:.2f}%")

        if val_acc > best_val_acc:
            best_val_acc = val_acc
            best_state = model.state_dict()

    model.load_state_dict(best_state)
    return model, history, best_val_acc


@torch.no_grad()
def test_model(model, test_loader, device):
    """测试并返回预测结果"""
    model.eval()
    all_labels, all_preds, all_scores = [], [], []
    for images, labels in test_loader:
        images = images.to(device)
        outputs = model(images)
        probs = torch.softmax(outputs, dim=1)
        preds = outputs.argmax(1)
        all_labels.extend(labels.numpy())
        all_preds.extend(preds.cpu().numpy())
        all_scores.extend(probs.cpu().numpy())
    return np.array(all_labels), np.array(all_preds), np.array(all_scores)


def main():
    parser = argparse.ArgumentParser(description="MLP vs LeNet-5 对照实验")
    parser.add_argument("--epochs", type=int, default=config.EPOCHS)
    parser.add_argument("--lr", type=float, default=config.LEARNING_RATE)
    args = parser.parse_args()

    set_seed(config.SEED)
    device = get_device()
    os.makedirs(config.RESULTS_DIR, exist_ok=True)
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    os.makedirs(config.CHECKPOINT_DIR, exist_ok=True)

    print("=" * 60)
    print("对照实验: MLP 基线 vs LeNet-5")
    print("=" * 60)
    save_environment_info()

    train_loader, val_loader, test_loader = load_mnist_data(batch_size=config.BATCH_SIZE)

    results = {}
    comparison_metrics = {}
    start = time.time()

    # --- 训练 MLP 基线 ---
    print("\n[1/2] 训练 MLP 基线模型...")
    mlp = build_mlp(num_classes=config.NUM_CLASSES).to(device)
    print(f"  MLP 参数量: {mlp.count_parameters():,}")
    mlp, mlp_history, mlp_val_acc = train_model(
        mlp, train_loader, val_loader, device, args.epochs, args.lr, "MLP"
    )
    y_true, y_pred, y_score = test_model(mlp, test_loader, device)
    mlp_metrics = compute_classification_metrics(y_true, y_pred, y_score)
    save_metrics_report(mlp_metrics, os.path.join(config.RESULTS_DIR, "mlp_metrics.txt"), "MLP")
    plot_training_curves(mlp_history, os.path.join(config.FIGURES_DIR, "mlp_training_curves.png"), "MLP")
    torch.save(mlp.state_dict(), os.path.join(config.CHECKPOINT_DIR, "mlp_model.pth"))
    results["MLP"] = {"val_acc": mlp_val_acc, "test_acc": mlp_metrics["accuracy"] * 100}
    comparison_metrics["MLP"] = mlp_metrics

    # --- 训练 LeNet-5 ---
    print("\n[2/2] 训练 LeNet-5 模型...")
    lenet = build_model(num_classes=config.NUM_CLASSES).to(device)
    print(f"  LeNet-5 参数量: {lenet.count_parameters():,}")
    lenet, lenet_history, lenet_val_acc = train_model(
        lenet, train_loader, val_loader, device, args.epochs, args.lr, "LeNet-5"
    )
    y_true, y_pred, y_score = test_model(lenet, test_loader, device)
    lenet_metrics = compute_classification_metrics(y_true, y_pred, y_score)
    save_metrics_report(lenet_metrics, os.path.join(config.RESULTS_DIR, "lenet_metrics.txt"), "LeNet-5")
    plot_training_curves(lenet_history, os.path.join(config.FIGURES_DIR, "lenet_training_curves.png"), "LeNet-5")
    torch.save(lenet.state_dict(), os.path.join(config.CHECKPOINT_DIR, "best_model.pth"))
    results["LeNet-5"] = {"val_acc": lenet_val_acc, "test_acc": lenet_metrics["accuracy"] * 100}
    comparison_metrics["LeNet-5"] = lenet_metrics

    elapsed = time.time() - start

    # --- 生成对照实验图表 ---
    plot_model_comparison(comparison_metrics, os.path.join(config.FIGURES_DIR, "model_comparison.png"))

    # --- 保存对照实验汇总 ---
    table_rows = [format_metrics_table_row(name, m) for name, m in comparison_metrics.items()]
    summary = {
        "experiment": "MLP vs LeNet-5",
        "epochs": args.epochs,
        "learning_rate": args.lr,
        "training_time_sec": round(elapsed, 1),
        "results": results,
        "comparison_table": table_rows,
        "last_epoch": {
            "MLP": {
                "train_acc": mlp_history["train_acc"][-1],
                "val_acc": mlp_history["val_acc"][-1],
            },
            "LeNet-5": {
                "train_acc": lenet_history["train_acc"][-1],
                "val_acc": lenet_history["val_acc"][-1],
            },
        },
    }
    save_history_json(summary, os.path.join(config.RESULTS_DIR, "comparison_summary.json"))

    print("\n" + "=" * 60)
    print("对照实验结果汇总")
    print("=" * 60)
    print(f"{'模型':<12}{'验证准确率':<14}{'测试准确率':<14}{'F1(macro)':<12}{'AUC(macro)':<12}")
    for name, m in comparison_metrics.items():
        auc = m.get("auc_macro")
        auc_str = f"{auc:.4f}" if auc else "—"
        print(f"{name:<12}{results[name]['val_acc']:.2f}%{'':<8}"
              f"{m['accuracy']*100:.2f}%{'':<8}{m['f1_macro']:.4f}{'':<6}{auc_str}")
    print(f"\n总耗时: {elapsed:.1f}s")
    print(f"对照实验图表: {config.FIGURES_DIR}/model_comparison.png")
    print("=" * 60)


if __name__ == "__main__":
    main()
