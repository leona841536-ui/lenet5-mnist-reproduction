"""
LeNet-5 模型训练脚本

用法:
    python train.py
    python train.py --epochs 15 --lr 0.001 --batch-size 128
"""

import os
import sys
import argparse
import random
import time

import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm

import config
from models.lenet5 import build_model
from utils.dataset import load_mnist_data, get_dataset_info
from utils.visualization import plot_training_curves, save_history_json
from utils.environment import save_environment_info


def set_seed(seed: int):
    """设置随机种子以保证实验可复现"""
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False


def get_device():
    """自动选择计算设备"""
    if torch.cuda.is_available():
        device = torch.device("cuda")
        print(f"使用 GPU: {torch.cuda.get_device_name(0)}")
    else:
        device = torch.device("cpu")
        print("使用 CPU 训练")
    return device


def train_one_epoch(model, loader, criterion, optimizer, device):
    """训练一个 epoch"""
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    pbar = tqdm(loader, desc="训练中", leave=False)
    for images, labels in pbar:
        images, labels = images.to(device), labels.to(device)

        optimizer.zero_grad()
        outputs = model(images)
        loss = criterion(outputs, labels)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

        pbar.set_postfix(loss=f"{loss.item():.4f}")

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    return epoch_loss, epoch_acc


@torch.no_grad()
def evaluate(model, loader, criterion, device):
    """在验证集/测试集上评估"""
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    for images, labels in loader:
        images, labels = images.to(device), labels.to(device)
        outputs = model(images)
        loss = criterion(outputs, labels)

        running_loss += loss.item() * images.size(0)
        _, predicted = outputs.max(1)
        total += labels.size(0)
        correct += predicted.eq(labels).sum().item()

    epoch_loss = running_loss / total
    epoch_acc = 100.0 * correct / total
    return epoch_loss, epoch_acc


def main():
    parser = argparse.ArgumentParser(description="LeNet-5 MNIST 训练")
    parser.add_argument("--epochs", type=int, default=config.EPOCHS)
    parser.add_argument("--batch-size", type=int, default=config.BATCH_SIZE)
    parser.add_argument("--lr", type=float, default=config.LEARNING_RATE)
    parser.add_argument("--weight-decay", type=float, default=config.WEIGHT_DECAY)
    parser.add_argument("--seed", type=int, default=config.SEED)
    args = parser.parse_args()

    # 初始化
    set_seed(args.seed)
    device = get_device()
    os.makedirs(config.CHECKPOINT_DIR, exist_ok=True)
    os.makedirs(config.FIGURES_DIR, exist_ok=True)
    save_environment_info()

    # 打印实验信息
    print("=" * 60)
    print("LeNet-5 手写数字识别 — 训练实验")
    print("=" * 60)
    info = get_dataset_info()
    for k, v in info.items():
        print(f"  {k}: {v}")
    print(f"  batch_size: {args.batch_size}")
    print(f"  epochs: {args.epochs}")
    print(f"  learning_rate: {args.lr}")
    print("=" * 60)

    # 加载数据
    print("\n加载 MNIST 数据集...")
    train_loader, val_loader, test_loader = load_mnist_data(
        batch_size=args.batch_size
    )
    print(f"  训练集: {len(train_loader.dataset)} 样本")
    print(f"  验证集: {len(val_loader.dataset)} 样本")
    print(f"  测试集: {len(test_loader.dataset)} 样本")

    # 构建模型
    model = build_model(num_classes=config.NUM_CLASSES).to(device)
    print(f"\n模型: LeNet-5")
    print(f"  参数量: {model.count_parameters():,}")

    # 损失函数与优化器
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(
        model.parameters(),
        lr=args.lr,
        weight_decay=args.weight_decay,
    )
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=5, gamma=0.5)

    # 训练循环
    history = {
        "train_loss": [], "train_acc": [],
        "val_loss": [], "val_acc": [],
    }
    best_val_acc = 0.0
    best_model_path = os.path.join(config.CHECKPOINT_DIR, "best_model.pth")

    print("\n开始训练...")
    start_time = time.time()

    for epoch in range(1, args.epochs + 1):
        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, device
        )
        val_loss, val_acc = evaluate(model, val_loader, criterion, device)
        scheduler.step()

        history["train_loss"].append(round(train_loss, 4))
        history["train_acc"].append(round(train_acc, 2))
        history["val_loss"].append(round(val_loss, 4))
        history["val_acc"].append(round(val_acc, 2))

        print(
            f"Epoch [{epoch:2d}/{args.epochs}] "
            f"Train Loss: {train_loss:.4f} Acc: {train_acc:.2f}% | "
            f"Val Loss: {val_loss:.4f} Acc: {val_acc:.2f}%"
        )

        # 保存最佳模型
        if val_acc > best_val_acc:
            best_val_acc = val_acc
            torch.save({
                "epoch": epoch,
                "model_state_dict": model.state_dict(),
                "optimizer_state_dict": optimizer.state_dict(),
                "val_acc": val_acc,
                "history": history,
            }, best_model_path)

    elapsed = time.time() - start_time
    print(f"\n训练完成! 耗时: {elapsed:.1f}s")
    print(f"最佳验证准确率: {best_val_acc:.2f}%")

    # 测试集最终评估
    checkpoint = torch.load(best_model_path, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint["model_state_dict"])
    test_loss, test_acc = evaluate(model, test_loader, criterion, device)
    print(f"测试集准确率: {test_acc:.2f}%  测试集损失: {test_loss:.4f}")

    history["test_acc"] = round(test_acc, 2)
    history["test_loss"] = round(test_loss, 4)
    history["best_val_acc"] = round(best_val_acc, 2)
    history["training_time_sec"] = round(elapsed, 1)

    # 保存结果
    save_history_json(history, os.path.join(config.RESULTS_DIR, "training_history.json"))
    plot_training_curves(
        history,
        save_path=os.path.join(config.FIGURES_DIR, "training_curves.png"),
    )

    # 保存最终模型
    final_path = os.path.join(config.CHECKPOINT_DIR, "final_model.pth")
    torch.save(model.state_dict(), final_path)
    print(f"\n模型已保存至: {config.CHECKPOINT_DIR}")
    print(f"结果图表已保存至: {config.FIGURES_DIR}")
    print("\n运行 python evaluate.py 进行详细评估与分析")


if __name__ == "__main__":
    main()
